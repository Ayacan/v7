var id = 0;

function _classPrivateFieldKey(name) {
  return "__private_" + id++ + "_" + name;
}

module.exports = _classPrivateFieldKey;
module.exports["default"] = module.exports, module.exports.__esModule = true;